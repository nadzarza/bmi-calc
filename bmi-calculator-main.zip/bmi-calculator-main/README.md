# HCI Project #2

## Project info

This project is built with:

- Vite
- TypeScript
- React
- shadcn-ui
- Tailwind CSS


